export abstract class ValueObject {}
