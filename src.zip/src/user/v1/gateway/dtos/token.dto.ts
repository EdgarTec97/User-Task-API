import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';

export class tokenDTO {
  @ApiProperty({
    example:
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c',
    description: 'Access token for user authentication',
  })
  @IsString()
  public readonly accessToken!: string;
  @ApiProperty({
    example:
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c',
    description: 'Refresh token for user authentication',
  })
  @IsString()
  public readonly refreshToken!: string;
  @ApiProperty({
    example: '3600',
    description: 'Expiration time for the access token',
  })
  @IsString()
  public readonly expirationTime!: string;
}
